def regexp(func):
    def wrapper():
        val1 = func() + "1"
        print(val1)

        return val1
    return wrapper


class FileReader:

    def __init__(self, fname):
        self.fname = fname

    @staticmethod
    @regexp
    def print_line(line):
        return line

    def read_file(self):
        with open(self.fname, "r") as f:

            while True:
                line = f.readline()
                if line != "":
                    print(self.print_line(line), end="")


if __name__ == "__main__":
    reader = FileReader(r'C:\Users\rwragg\Desktop\fun.txt')
    reader.read_file()
